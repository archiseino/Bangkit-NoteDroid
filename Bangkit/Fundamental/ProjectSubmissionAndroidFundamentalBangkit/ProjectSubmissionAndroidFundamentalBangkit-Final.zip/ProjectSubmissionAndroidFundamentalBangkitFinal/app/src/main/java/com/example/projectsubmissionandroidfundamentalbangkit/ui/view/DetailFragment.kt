package com.example.projectsubmissionandroidfundamentalbangkit.ui.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.projectsubmissionandroidfundamentalbangkit.R
import com.example.projectsubmissionandroidfundamentalbangkit.adapter.ViewStateAdapter
import com.example.projectsubmissionandroidfundamentalbangkit.data.local.entity.UserEntity
import com.example.projectsubmissionandroidfundamentalbangkit.databinding.FragmentDetailBinding
import com.example.projectsubmissionandroidfundamentalbangkit.utils.ViewModelFactory
import com.example.projectsubmissionandroidfundamentalbangkit.ui.viewmodel.DetailViewModel
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailFragment : Fragment() {

    companion object {
        lateinit var USER_NAME: String
    }

    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    private val args: DetailFragmentArgs by navArgs()
    private var isAdded : Boolean = false

    private lateinit var viewModel: DetailViewModel
    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var topAppBar: MaterialToolbar
    private lateinit var loadingIndicator: LinearProgressIndicator
    private lateinit var fab: FloatingActionButton
    private lateinit var userEntity: UserEntity


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(layoutInflater, container, false)

        val factory : ViewModelFactory = ViewModelFactory.getInstance(requireActivity().applicationContext)
        viewModel = ViewModelProvider(this, factory)[DetailViewModel::class.java]

        setupViewPager()
        loadUserDetail()

        return binding.root
    }


    private fun setupViewPager() {
        tabLayout = binding.tabLayout
        viewPager = binding.viewPager
        viewPager.adapter = ViewStateAdapter(childFragmentManager, lifecycle)

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text =
                    if (position == 0) getText(R.string.tab_followers) else getText(R.string.tab_following)
        }.attach()
    }

    private fun loadUserDetail() {
        USER_NAME = args.username

        loadingIndicator = binding.layoutHeader.isLoading
        topAppBar = binding.topAppBar
        topAppBar.apply {
            setNavigationOnClickListener {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
            title = USER_NAME
        }

        viewModel.apply {
            setUsername(USER_NAME)
            detailProfile()

            isLoading.observe(viewLifecycleOwner) { isLoading ->
                if (isLoading) loadingIndicator.show() else loadingIndicator.hide()
            }

            user.observe(viewLifecycleOwner) { user ->
                userEntity = UserEntity(
                    login = user?.login,
                    avatarUrl = user?.avatarUrl
                )
                with(binding) {
                    layoutHeader.tvName.text = user?.name
                    layoutHeader.tvUsername.text = user?.login
                    layoutHeader.tvFollower.text = user?.followers.toString()
                    layoutHeader.tvFollowing.text = user?.following.toString()

                    Glide.with(binding.root.context)
                        .load(user?.avatarUrl)
                        .into(layoutHeader.ivProfilePic)
                }
            }

            isFavoritesUser(USER_NAME)
            isFavorite.observe(viewLifecycleOwner){isFavorite ->
                if (isFavorite) {
                    isAdded = true
                    fab.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.baseline_favorite_24))
                } else {
                    isAdded = false
                    fab.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.baseline_favorite_border_24))
                }

            }

            fab = binding.fabFavorite
            fab.setOnClickListener {
                isAdded = if (isAdded) {
                    deleteUser(USER_NAME)
                    fab.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.baseline_favorite_border_24))
                    Snackbar.make(binding.root, resources.getString(R.string.success_remove_user), Snackbar.LENGTH_SHORT).show()
                    false
                } else {
                    insertUser(userEntity)
                    fab.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.baseline_favorite_24))
                    Snackbar.make(binding.root, resources.getString(R.string.success_add_user), Snackbar.LENGTH_SHORT).show()
                    true
                }
            }

        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}